require 'fake_web'

FakeWeb.allow_net_connect = false
