require 'paperclip/railtie'
Paperclip::Railtie.insert
