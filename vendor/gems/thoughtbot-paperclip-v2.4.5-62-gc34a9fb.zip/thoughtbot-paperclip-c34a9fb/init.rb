require File.join(File.dirname(__FILE__), "lib", "paperclip")
require 'paperclip/railtie'

Paperclip::Railtie.insert
