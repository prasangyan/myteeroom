module Paperclip
  VERSION = "2.4.5" unless defined? Paperclip::VERSION
end
