For installation instructions see http://rmagick.rubyforge.org/install-osx.html
